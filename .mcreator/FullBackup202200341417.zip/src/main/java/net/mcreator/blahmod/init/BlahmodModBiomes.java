
/*
 *	MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.blahmod.init;

import net.minecraft.world.level.biome.Biome;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.resources.ResourceKey;
import net.minecraft.core.Registry;

import net.mcreator.blahmod.world.biome.TropicsBiome;
import net.mcreator.blahmod.BlahmodMod;

public class BlahmodModBiomes {
	public static ResourceKey<Biome> TROPICS = ResourceKey.create(Registry.BIOME_REGISTRY, new ResourceLocation(BlahmodMod.MODID, "tropics"));

	public static void load() {
		TropicsBiome.createBiome();
	}
}
